import{c}from"./index-BT7wvqvA.js";const e=c("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{e as C};
