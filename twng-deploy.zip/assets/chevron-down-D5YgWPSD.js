import{c as o}from"./index-BT7wvqvA.js";const n=o("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{n as C};
