import{c as e}from"./index-BT7wvqvA.js";const c=e("check-check",[["path",{d:"M18 6 7 17l-5-5",key:"116fxf"}],["path",{d:"m22 10-7.5 7.5L13 16",key:"ke71qq"}]]);export{c as C};
