import{c as o}from"./index-BT7wvqvA.js";const e=o("chevron-up",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);export{e as C};
