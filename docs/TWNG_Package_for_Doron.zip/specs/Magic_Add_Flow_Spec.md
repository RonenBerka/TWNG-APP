# TWNG — Magic Add Flow Specification

> **Feature:** AI-Powered Guitar Identification
> **Version:** 1.0
> **Priority:** P0 (Core Feature)

---

## Overview

### What is Magic Add?
Magic Add lets users photograph a guitar and have TWNG automatically identify the brand, model, year, and specs. It's the "magic" that makes TWNG different from a spreadsheet.

### User Value
- **Speed:** 30 seconds vs 5+ minutes manual entry
- **Accuracy:** AI knows specs users might miss
- **Discovery:** Learn things about your guitar you didn't know
- **Delight:** "Wow, it knows what this is!"

### Success Metrics
| Metric | Target |
|--------|--------|
| Identification accuracy | >75% first guess |
| User correction rate | <25% |
| Time to complete | <60 seconds |
| Feature adoption | >70% of new guitars |

---

## User Flow

### Happy Path

```
┌─────────────────┐
│ 1. Tap "+" to   │
│    add guitar   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 2. Choose       │
│    "Magic Add"  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 3. Camera opens │
│    or choose    │
│    from gallery │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 4. Take photo   │
│    (guidance    │
│    overlay)     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 5. Processing   │
│    "Identifying │
│    your guitar" │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 6. Results      │
│    shown with   │
│    confidence   │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌───────┐ ┌───────┐
│Correct│ │ Edit  │
└───┬───┘ └───┬───┘
    │         │
    ▼         ▼
┌─────────────────┐
│ 7. Choose       │
│    visibility   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 8. Success!     │
│    Saved to     │
│    collection   │
└─────────────────┘
```

---

## Screen Specifications

### Screen 1: Add Guitar Choice

```
┌─────────────────────────────────────────────┐
│                                             │
│   Add a guitar                              │
│   ─────────────                             │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   📸 Magic Add                      │   │
│   │   ───────────                       │   │
│   │   Take a photo — we'll identify     │   │
│   │   it and fill in the details.       │   │
│   │                                     │   │
│   │   ✨ Recommended                    │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   ✏️ Add Manually                   │   │
│   │   ───────────                       │   │
│   │   Enter the details yourself.       │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   [Cancel]                                  │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 2: Camera / Photo Selection

```
┌─────────────────────────────────────────────┐
│  ✕                              [Gallery 🖼]│
│─────────────────────────────────────────────│
│                                             │
│                                             │
│         ┌───────────────────────┐           │
│         │                       │           │
│         │    CAMERA VIEWFINDER  │           │
│         │                       │           │
│         │   ┌───────────────┐   │           │
│         │   │ Headstock     │   │  ← Guide  │
│         │   │ outline       │   │    overlay│
│         │   └───────────────┘   │           │
│         │                       │           │
│         └───────────────────────┘           │
│                                             │
│   💡 Tip: Include the headstock for         │
│      best identification                    │
│                                             │
│              ┌─────────┐                    │
│              │    ◉    │  ← Capture button  │
│              └─────────┘                    │
│                                             │
└─────────────────────────────────────────────┘
```

**Camera Guidance:**
- Overlay suggests headstock position
- Tip text rotates: "Include headstock", "Good lighting helps", "Show the full body"
- Option to use flash
- Gallery picker for existing photos

---

### Screen 3: Processing State

```
┌─────────────────────────────────────────────┐
│                                             │
│                                             │
│                                             │
│              ┌─────────────┐                │
│              │             │                │
│              │   [Photo]   │                │
│              │             │                │
│              └─────────────┘                │
│                                             │
│              ◐ ◓ ◑ ◒                        │
│                                             │
│         Identifying your guitar...          │
│                                             │
│         "Checking 120+ brands"              │
│         "Analyzing features"                │
│         "Matching specs"                    │
│                                             │
│                                             │
└─────────────────────────────────────────────┘
```

**Processing Messages (rotate):**
- "Identifying your guitar..."
- "Checking 120+ brands..."
- "Analyzing the headstock..."
- "Looking up specs..."
- "Almost there..."

**Timing:**
- Target: 3-5 seconds
- Max timeout: 15 seconds
- Show "Taking longer than usual..." after 8 seconds

---

### Screen 4: Results — High Confidence (>80%)

```
┌─────────────────────────────────────────────┐
│  ← Back                                     │
│─────────────────────────────────────────────│
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │          [User's Photo]             │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ✓ We found it!                            │
│                                             │
│   🎸 Fender Stratocaster                    │
│      American Professional II               │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │ Year        2021                    │   │
│   │ Country     USA                     │   │
│   │ Body        Alder                   │   │
│   │ Neck        Maple                   │   │
│   │ Pickups     V-Mod II Single Coil    │   │
│   │ Color       Olympic White           │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   Serial Number (if visible)                │
│   ┌─────────────────────────────────────┐   │
│   │ US21034567                          │   │
│   └─────────────────────────────────────┘   │
│   ✓ Decoded: Made in Corona, CA, 2021       │
│                                             │
│   ┌───────────────┐  ┌───────────────┐      │
│   │  ✓ Correct    │  │   ✏️ Edit     │      │
│   └───────────────┘  └───────────────┘      │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 4b: Results — Medium Confidence (50-80%)

```
┌─────────────────────────────────────────────┐
│  ← Back                                     │
│─────────────────────────────────────────────│
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │          [User's Photo]             │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   🤔 We think this is...                    │
│                                             │
│   🎸 Gibson Les Paul Standard               │
│      (or similar model)                     │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │ Year        2015-2019 (estimated)   │   │
│   │ Country     USA                     │   │
│   │ Pickups     Burstbucker             │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ⚠️ We're not 100% sure. Please verify     │
│      the details before saving.             │
│                                             │
│   ┌───────────────┐  ┌───────────────┐      │
│   │  ✓ Correct    │  │   ✏️ Edit     │      │
│   └───────────────┘  └───────────────┘      │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 4c: Results — Low Confidence (<50%)

```
┌─────────────────────────────────────────────┐
│  ← Back                                     │
│─────────────────────────────────────────────│
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │          [User's Photo]             │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   🔍 We need your help                      │
│                                             │
│   We couldn't identify this guitar          │
│   with confidence. Here's our best guess:   │
│                                             │
│   🎸 Possibly: Tokai Love Rock              │
│      (Japanese Les Paul style)              │
│                                             │
│   ─────────────────────────────────────     │
│                                             │
│   Want to try again with a better photo?    │
│                                             │
│   💡 Tips:                                  │
│   • Include the headstock clearly           │
│   • Use good lighting                       │
│   • Show any logos or text                  │
│                                             │
│   ┌───────────────┐  ┌───────────────┐      │
│   │  📸 Retake    │  │  ✏️ Enter     │      │
│   │     Photo     │  │   Manually    │      │
│   └───────────────┘  └───────────────┘      │
│                                             │
│   [ Use this guess anyway → ]               │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 4d: Results — No Match

```
┌─────────────────────────────────────────────┐
│  ← Back                                     │
│─────────────────────────────────────────────│
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │          [User's Photo]             │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   😕 We couldn't identify this guitar       │
│                                             │
│   This might be:                            │
│   • A custom or handmade guitar             │
│   • A rare or unusual brand                 │
│   • Hard to see in the photo                │
│                                             │
│   ─────────────────────────────────────     │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   📸 Try a different photo          │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   ✏️ Add manually instead           │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 5: Edit Identification

```
┌─────────────────────────────────────────────┐
│  ← Back                          [Save]     │
│─────────────────────────────────────────────│
│                                             │
│   Edit Details                              │
│   ────────────                              │
│                                             │
│   Brand *                                   │
│   ┌─────────────────────────────────────┐   │
│   │ Gibson                          [▼] │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   Model *                                   │
│   ┌─────────────────────────────────────┐   │
│   │ Les Paul Classic                    │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   Year                                      │
│   ┌─────────────────────────────────────┐   │
│   │ 2019                                │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   Country                                   │
│   ┌─────────────────────────────────────┐   │
│   │ USA                             [▼] │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   Serial Number                             │
│   ┌─────────────────────────────────────┐   │
│   │ 190012345                           │   │
│   └─────────────────────────────────────┘   │
│   [Decode →]                                │
│                                             │
│   Color / Finish                            │
│   ┌─────────────────────────────────────┐   │
│   │ Heritage Cherry Sunburst            │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ─────────────────────────────────────     │
│   What did we get wrong? (helps us improve) │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ☐ Share this correction to help           │
│     improve Magic Add                       │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 6: Visibility Selection

*(See Visibility_Selector_Spec.md for details)*

```
┌─────────────────────────────────────────────┐
│                                             │
│   Who can see this guitar?                  │
│   ────────────────────────                  │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │ ● 🔒 Private — Only you             │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │ ○ 🔗 Link — Anyone with link        │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │ ○ 🌐 Public — Everyone              │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   [Save to My Collection]                   │
│                                             │
└─────────────────────────────────────────────┘
```

---

### Screen 7: Success

```
┌─────────────────────────────────────────────┐
│                                             │
│                                             │
│                  ✓                          │
│                                             │
│   Done! Your Fender Stratocaster            │
│   is saved.                                 │
│                                             │
│   🔒 Private — only you can see it          │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   [+ Add another guitar]            │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   [Go to My Collection]             │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │                                     │   │
│   │   [Add story to this guitar →]      │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                                             │
└─────────────────────────────────────────────┘
```

---

## Edge Cases

### Image Too Dark/Blurry

```
Detection: Image quality score < threshold

Response:
┌─────────────────────────────────────────────┐
│                                             │
│   📷 Photo might be too dark                │
│                                             │
│   We'll try to identify it, but a           │
│   clearer photo might give better results.  │
│                                             │
│   [Try anyway]  [Retake photo]              │
│                                             │
└─────────────────────────────────────────────┘
```

### No Headstock Visible

```
Detection: Headstock not detected in image

Response:
┌─────────────────────────────────────────────┐
│                                             │
│   🎸 Can you show the headstock?            │
│                                             │
│   The headstock helps us identify the       │
│   brand. Add another photo?                 │
│                                             │
│   [Add photo]  [Continue without]           │
│                                             │
└─────────────────────────────────────────────┘
```

### Multiple Guitars in Photo

```
Detection: Multiple instruments detected

Response:
┌─────────────────────────────────────────────┐
│                                             │
│   🎸🎸 We see multiple guitars              │
│                                             │
│   Please take a photo of just one           │
│   guitar at a time.                         │
│                                             │
│   [Retake photo]                            │
│                                             │
└─────────────────────────────────────────────┘
```

### Not a Guitar

```
Detection: No guitar detected

Response:
┌─────────────────────────────────────────────┐
│                                             │
│   🤔 We don't see a guitar                  │
│                                             │
│   Make sure the guitar is clearly           │
│   visible in the photo.                     │
│                                             │
│   [Try again]  [Add manually]               │
│                                             │
└─────────────────────────────────────────────┘
```

### Network Error

```
Detection: API timeout or failure

Response:
┌─────────────────────────────────────────────┐
│                                             │
│   📶 Connection problem                     │
│                                             │
│   We couldn't reach our servers.            │
│   Check your connection and try again.      │
│                                             │
│   [Retry]  [Add manually]                   │
│                                             │
└─────────────────────────────────────────────┘
```

---

## Technical Integration

### API Endpoint

```
POST /api/v1/magic-add/identify

Request:
{
  "image": "base64_encoded_image",
  "image_format": "jpeg",
  "hints": {
    "user_suggested_brand": "Fender",  // optional
    "serial_number": "US21034567"       // optional, if OCR'd
  }
}

Response:
{
  "success": true,
  "confidence": 0.87,
  "identification": {
    "brand": "Fender",
    "model": "Stratocaster",
    "series": "American Professional II",
    "year": 2021,
    "year_range": null,
    "country": "USA",
    "body_wood": "Alder",
    "neck_wood": "Maple",
    "fretboard": "Rosewood",
    "pickups": "V-Mod II Single Coil",
    "color": "Olympic White"
  },
  "serial_decode": {
    "serial": "US21034567",
    "year": 2021,
    "factory": "Corona, CA",
    "verified": true
  },
  "alternatives": [
    {
      "confidence": 0.12,
      "identification": {
        "brand": "Fender",
        "model": "Stratocaster",
        "series": "American Original 60s"
      }
    }
  ],
  "image_hash": "abc123..."
}
```

### Confidence Levels

| Level | Range | UI Treatment |
|-------|-------|--------------|
| High | >80% | "We found it!" |
| Medium | 50-80% | "We think this is..." |
| Low | 20-50% | "We need your help" |
| None | <20% | "Couldn't identify" |

---

## Integration with Feedback Loop

When user confirms or corrects:

```typescript
// After user confirms
if (userAction === 'confirm') {
  await submitVerification({
    guitar_id: newGuitarId,
    status: 'confirmed',
    ai_guess: aiResult.identification,
    final_identification: aiResult.identification,
    ai_confidence: aiResult.confidence,
    share_image: userOptedIn
  });
}

// After user corrects
if (userAction === 'correct') {
  await submitVerification({
    guitar_id: newGuitarId,
    status: 'corrected',
    ai_guess: aiResult.identification,
    final_identification: userCorrection,
    ai_confidence: aiResult.confidence,
    corrections_note: userNote,
    share_image: userOptedIn
  });
}
```

---

## Accessibility

- All images have alt text describing the guitar
- Loading states announced to screen readers
- Color is not the only indicator (icons + text)
- Touch targets minimum 44x44px
- Keyboard navigation supported

---

## Analytics Events

| Event | When | Data |
|-------|------|------|
| `magic_add_started` | User opens camera | - |
| `photo_taken` | User captures/selects photo | source: camera/gallery |
| `identification_complete` | AI returns result | confidence, brand, time_ms |
| `user_confirmed` | User taps "Correct" | confidence |
| `user_corrected` | User edits & saves | fields_changed[] |
| `retake_photo` | User chooses to retake | reason |
| `fallback_manual` | User gives up, goes manual | confidence |

---

## Performance Requirements

| Metric | Target | Max |
|--------|--------|-----|
| Image upload | <2s | 5s |
| AI processing | <4s | 10s |
| Total time | <6s | 15s |
| Image size limit | - | 10MB |

---

## Future Enhancements

1. **Multi-photo identification** — Add more photos for better accuracy
2. **Video identification** — Walk around the guitar
3. **AR overlay** — Show identified specs in AR
4. **Batch identification** — Identify multiple guitars at once
5. **Offline mode** — Queue for later identification

---

*"Point. Shoot. Done."*
